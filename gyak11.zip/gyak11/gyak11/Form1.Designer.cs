﻿namespace gyak11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UC1 = new Button();
            UC2 = new Button();
            panel1 = new Panel();
            SuspendLayout();
            // 
            // UC1
            // 
            UC1.Anchor = AnchorStyles.None;
            UC1.Location = new Point(12, 12);
            UC1.Name = "UC1";
            UC1.Size = new Size(107, 111);
            UC1.TabIndex = 0;
            UC1.Text = "UserControl1";
            UC1.UseVisualStyleBackColor = true;
            UC1.Click += UC1_Click;
            // 
            // UC2
            // 
            UC2.Anchor = AnchorStyles.None;
            UC2.Location = new Point(12, 138);
            UC2.Name = "UC2";
            UC2.Size = new Size(107, 106);
            UC2.TabIndex = 1;
            UC2.Text = "UserControl2";
            UC2.UseVisualStyleBackColor = true;
            UC2.Click += UC2_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.Location = new Point(136, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(665, 447);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(UC1);
            Controls.Add(panel1);
            Controls.Add(UC2);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button UC1;
        private Button UC2;
        private Panel panel1;
    }
}